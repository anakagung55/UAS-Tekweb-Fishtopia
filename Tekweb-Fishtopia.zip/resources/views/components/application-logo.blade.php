<img src="images/img4.png" class="w-1/2 transition-transform transform hover:scale-110">
<div class="flex-grow ml-4">
    <p class="text-gray-800 font-bold">Fishtopia.</p>
</div>