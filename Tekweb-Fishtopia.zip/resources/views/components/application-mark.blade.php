<div class="flex items-center">
    <img src="images/img4.png" class="w-1/2 transition-transform transform hover:scale-110">
    <div class="flex-grow ml-4 mr-10">
        <p class="text-gray-800 font-bold hover:text-gray-500 w-1/2 transition-transform transform hover:font-extrabold">Fishtopia.</p>
    </div>
</div>
