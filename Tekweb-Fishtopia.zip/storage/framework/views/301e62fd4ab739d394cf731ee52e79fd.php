<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['textColor', 'bgColor']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['textColor', 'bgColor']); ?>
<?php foreach (array_filter((['textColor', 'bgColor']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $textColor = match ($textColor) {
        'gray' => 'text-gray-800',
        'blue' => 'text-blue-800',
        'red' => 'text-red-800',
        'yellow' => 'text-yellow-800',
        'pink' => 'text-pink-800',
        'indigo' => 'text-indigo-800',
        'purple' => 'text-purple-800',
        'green' => 'text-green-800',
        'lime' => 'text-lime-800',
        default => 'text-gray-800',
    };
    
    $bgColor = match ($bgColor) {
        'gray' => 'bg-gray-100',
        'blue' => 'bg-blue-100',
        'red' => 'bg-red-100',
        'yellow' => 'bg-yellow-100',
        'pink' => 'bg-pink-100',
        'indigo' => 'bg-indigo-100',
        'purple' => 'bg-purple-100',
        'green' => 'bg-green-100',
        'lime' => 'bg-lime-100',
        default => 'bg-gray-100',
    };
?>

<button <?php echo e($attributes); ?> class="<?php echo e($textColor); ?> <?php echo e($bgColor); ?> rounded-xl px-3 py-1 text-base">
    <?php echo e($slot); ?> </button>
<?php /**PATH C:\Users\62877\Desktop\yoyoyoyo\Tekweb-Fishtopia\resources\views/components/badge.blade.php ENDPATH**/ ?>